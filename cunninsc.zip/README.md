# Topics in Functional Programming
## Assignment 2

Scott Cunningham / 10311491 / cunninsc@tcd.ie

All parts of the assignment can be found in Interp-partX.lhs where X is the part number.
Input code files with examples for all parts after part 1 (for the interpreter function) can be found in inX.in where X is the part number again.

All parts have "main" defined to run through some example of the added feature for that part.

A note on part 5 - 
In part 5 I traverse the AST to look for trivial code paths (eg while/if with tautologies in the condition).
